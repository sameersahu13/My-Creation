OpenLayers v4.6.5

Taken from https://github.com/openlayers/openlayers/releases/download/v4.6.5/v4.6.5-dist.zip
